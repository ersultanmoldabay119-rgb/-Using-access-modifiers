using CollegeManagement.Models;
using Microsoft.AspNetCore.Identity;

namespace CollegeManagement.Data;

/// <summary>
/// Заполняет пустую базу демонстрационными данными.
/// Оценки и посещаемость генерируются относительно текущей даты, чтобы дашборд был «живым».
/// </summary>
public static class DbSeeder
{
    public static void Seed(CollegeDbContext db)
    {
        if (db.Users.Any())
            return;

        var rnd = new Random(2024);

        var teachers = new List<Teacher>
        {
            T("Ахметова", "Гульнара", "Сериковна", "Заведующая отделением", 2009),
            T("Петров", "Андрей", "Викторович", "Старший преподаватель", 2014),
            T("Жумабаев", "Ерлан", "Каиратович", "Преподаватель", 2017),
            T("Смирнова", "Ольга", "Николаевна", "Преподаватель", 2012),
            T("Касымова", "Айжан", "Болатовна", "Преподаватель", 2019),
            T("Ли", "Виктор", "Александрович", "Старший преподаватель", 2011),
            T("Омаров", "Нурлан", "Маратович", "Преподаватель", 2021),
            T("Сатпаева", "Динара", "Ержановна", "Преподаватель", 2016),
        };
        db.Teachers.AddRange(teachers);

        var subjects = new List<Subject>
        {
            new() { Name = "Программирование на C#", Hours = 144, Teacher = teachers[1] },
            new() { Name = "Базы данных", Hours = 108, Teacher = teachers[2] },
            new() { Name = "Веб-разработка", Hours = 120, Teacher = teachers[6] },
            new() { Name = "Математика", Hours = 96, Teacher = teachers[3] },
            new() { Name = "Английский язык", Hours = 72, Teacher = teachers[4] },
            new() { Name = "Компьютерные сети", Hours = 90, Teacher = teachers[5] },
            new() { Name = "Операционные системы", Hours = 80, Teacher = teachers[5] },
            new() { Name = "История Казахстана", Hours = 60, Teacher = teachers[7] },
        };
        db.Subjects.AddRange(subjects);

        var groups = new List<Group>
        {
            new() { Name = "ПО-22", Specialty = "Программное обеспечение", Course = 3, Curator = teachers[1] },
            new() { Name = "ПО-23", Specialty = "Программное обеспечение", Course = 2, Curator = teachers[2] },
            new() { Name = "ИС-23", Specialty = "Информационные системы", Course = 2, Curator = teachers[3] },
            new() { Name = "ВТ-24", Specialty = "Вычислительная техника", Course = 1, Curator = teachers[5] },
        };
        db.Groups.AddRange(groups);

        string[] maleNames = { "Алихан", "Нурсултан", "Данияр", "Арман", "Тимур", "Айдос", "Бекзат", "Максим",
                               "Артём", "Дмитрий", "Ильяс", "Санжар", "Ернар", "Даулет", "Кирилл", "Адиль" };
        string[] femaleNames = { "Айгерим", "Асель", "Дана", "Мадина", "Алина", "Камила", "Жания", "Анастасия",
                                 "Сабина", "Томирис", "Аружан", "Виктория", "Динара", "Елизавета" };
        string[] surnames = { "Сериков", "Ахметов", "Касымов", "Иванов", "Омаров", "Бекмуханов", "Абдрахманов",
                              "Тулегенов", "Нуртаев", "Каримов", "Кузнецов", "Есенов", "Мухамедов", "Байжанов",
                              "Волков", "Исмаилов", "Жаксылыков", "Морозов", "Ибраев", "Попов", "Султанов" };

        var today = DateTime.Today;
        var students = new List<(Student Student, double Ability, double Diligence)>();
        var usedNames = new HashSet<string>();

        foreach (var group in groups)
        {
            var count = rnd.Next(13, 17);
            for (var i = 0; i < count; i++)
            {
                string first, last;
                do
                {
                    var female = rnd.NextDouble() < 0.45;
                    first = female ? femaleNames[rnd.Next(femaleNames.Length)] : maleNames[rnd.Next(maleNames.Length)];
                    last = surnames[rnd.Next(surnames.Length)] + (female ? "а" : "");
                } while (!usedNames.Add(first + last));

                var student = new Student
                {
                    FirstName = first,
                    LastName = last,
                    Group = group,
                    BirthDate = new DateTime(2009 - group.Course, rnd.Next(1, 13), rnd.Next(1, 29)),
                    EnrollmentDate = new DateTime(today.Year - group.Course + (today.Month >= 9 ? 1 : 0), 9, 1),
                    Email = $"{Translit(first)}.{Translit(last)}@college.kz".ToLowerInvariant(),
                    Phone = $"+7 70{rnd.Next(0, 9)} {rnd.Next(100, 999)} {rnd.Next(10, 99)} {rnd.Next(10, 99)}",
                };
                // «Способности» влияют на оценки, «дисциплина» — на посещаемость.
                students.Add((student, 2.7 + rnd.NextDouble() * 2.3, 0.78 + rnd.NextDouble() * 0.21));
            }
        }
        db.Students.AddRange(students.Select(s => s.Student));

        var schoolDays = Enumerable.Range(0, 42)
            .Select(d => today.AddDays(-d))
            .Where(d => d.DayOfWeek is not DayOfWeek.Saturday and not DayOfWeek.Sunday)
            .OrderBy(d => d)
            .ToList();

        foreach (var (student, ability, diligence) in students)
        {
            foreach (var day in schoolDays)
            {
                var roll = rnd.NextDouble();
                var status = roll < diligence ? AttendanceStatus.Present
                    : roll < diligence + (1 - diligence) * 0.35 ? AttendanceStatus.Late
                    : roll < diligence + (1 - diligence) * 0.55 ? AttendanceStatus.Excused
                    : AttendanceStatus.Absent;
                db.Attendance.Add(new Attendance { Student = student, Date = day, Status = status });
            }

            foreach (var subject in subjects)
            {
                var gradesCount = rnd.Next(3, 7);
                for (var i = 0; i < gradesCount; i++)
                {
                    var noise = (rnd.NextDouble() - 0.5) * 1.6;
                    var value = Math.Clamp((int)Math.Round(ability + noise), 2, 5);
                    db.Grades.Add(new Grade
                    {
                        Student = student,
                        Subject = subject,
                        Value = value,
                        Date = schoolDays[rnd.Next(schoolDays.Count)],
                        Type = rnd.NextDouble() < 0.15 ? GradeType.Test : GradeType.Current,
                    });
                }
            }
        }

        var hasher = new PasswordHasher<User>();
        var admin = new User { Username = "admin", DisplayName = "Администратор", Role = Roles.Admin };
        admin.PasswordHash = hasher.HashPassword(admin, "admin123");
        var teacherUser = new User { Username = "teacher", DisplayName = "Петров А. В.", Role = Roles.Teacher, Teacher = teachers[1] };
        teacherUser.PasswordHash = hasher.HashPassword(teacherUser, "teacher123");
        db.Users.AddRange(admin, teacherUser);

        db.SaveChanges();
    }

    private static Teacher T(string last, string first, string middle, string position, int hiredYear) => new()
    {
        LastName = last,
        FirstName = first,
        MiddleName = middle,
        Position = position,
        HireDate = new DateTime(hiredYear, 8, 25),
        Email = $"{Translit(first)[0]}.{Translit(last)}@college.kz".ToLowerInvariant(),
        Phone = "+7 727 " + (200 + last.Length * 37) + " 10 " + (10 + first.Length * 7),
    };

    private static string Translit(string s)
    {
        var map = new Dictionary<char, string>
        {
            ['а'] = "a", ['б'] = "b", ['в'] = "v", ['г'] = "g", ['д'] = "d", ['е'] = "e", ['ё'] = "e", ['ж'] = "zh",
            ['з'] = "z", ['и'] = "i", ['й'] = "y", ['к'] = "k", ['л'] = "l", ['м'] = "m", ['н'] = "n", ['о'] = "o",
            ['п'] = "p", ['р'] = "r", ['с'] = "s", ['т'] = "t", ['у'] = "u", ['ф'] = "f", ['х'] = "kh", ['ц'] = "ts",
            ['ч'] = "ch", ['ш'] = "sh", ['щ'] = "sch", ['ы'] = "y", ['э'] = "e", ['ю'] = "yu", ['я'] = "ya",
            ['ь'] = "", ['ъ'] = "",
        };
        return string.Concat(s.ToLowerInvariant().Select(c => map.TryGetValue(c, out var r) ? r : c.ToString()));
    }
}
