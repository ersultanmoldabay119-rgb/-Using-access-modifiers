using CollegeManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Data;

public class CollegeDbContext : DbContext
{
    public CollegeDbContext(DbContextOptions<CollegeDbContext> options) : base(options) { }

    public DbSet<Student> Students => Set<Student>();
    public DbSet<Teacher> Teachers => Set<Teacher>();
    public DbSet<Group> Groups => Set<Group>();
    public DbSet<Subject> Subjects => Set<Subject>();
    public DbSet<Grade> Grades => Set<Grade>();
    public DbSet<Attendance> Attendance => Set<Attendance>();
    public DbSet<User> Users => Set<User>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Group>(e =>
        {
            e.HasIndex(g => g.Name).IsUnique();
            e.HasOne(g => g.Curator)
                .WithMany(t => t.CuratedGroups)
                .HasForeignKey(g => g.CuratorId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        // Группу с студентами удалить нельзя — сначала нужно перевести студентов.
        modelBuilder.Entity<Student>()
            .HasOne(s => s.Group)
            .WithMany(g => g.Students)
            .HasForeignKey(s => s.GroupId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Subject>()
            .HasOne(s => s.Teacher)
            .WithMany(t => t.Subjects)
            .HasForeignKey(s => s.TeacherId)
            .OnDelete(DeleteBehavior.SetNull);

        modelBuilder.Entity<Grade>(e =>
        {
            e.HasOne(g => g.Student).WithMany(s => s.Grades).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(g => g.Subject).WithMany(s => s.Grades).OnDelete(DeleteBehavior.Cascade);
            e.HasIndex(g => g.Date);
        });

        modelBuilder.Entity<Attendance>(e =>
        {
            e.HasOne(a => a.Student).WithMany(s => s.AttendanceRecords).OnDelete(DeleteBehavior.Cascade);
            e.HasIndex(a => new { a.StudentId, a.Date }).IsUnique();
            e.HasIndex(a => a.Date);
        });

        modelBuilder.Entity<User>(e =>
        {
            e.HasIndex(u => u.Username).IsUnique();
            e.HasOne(u => u.Teacher).WithMany().HasForeignKey(u => u.TeacherId).OnDelete(DeleteBehavior.SetNull);
        });
    }
}
