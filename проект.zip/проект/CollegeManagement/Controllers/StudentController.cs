using CollegeManagement.Data;
using CollegeManagement.Infrastructure;
using CollegeManagement.Models;
using CollegeManagement.Models.ViewModels;
using CollegeManagement.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;

public class StudentController : Controller
{
    private readonly StudentService _students;
    private readonly CollegeDbContext _db;

    public StudentController(StudentService students, CollegeDbContext db)
    {
        _students = students;
        _db = db;
    }

    public async Task<IActionResult> Index(string? search, int? groupId)
    {
        return View(new StudentListViewModel
        {
            Search = search,
            GroupId = groupId,
            Students = await _students.GetListAsync(search, groupId),
            Groups = await _db.GroupOptionsAsync(groupId)
        });
    }

    public async Task<IActionResult> Details(int id)
    {
        var profile = await _students.GetProfileAsync(id);
        return profile is null ? NotFound() : View(profile);
    }

    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Create(int? groupId)
    {
        var student = new Student { GroupId = groupId ?? 0 };
        return View(await FormAsync(student));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Create([Bind(Prefix = "Student")] Student student)
    {
        if (!ModelState.IsValid)
            return View(await FormAsync(student));

        await _students.CreateAsync(student);
        TempData["Toast"] = $"Студент {student.ShortName} добавлен";
        return RedirectToAction(nameof(Details), new { id = student.Id });
    }

    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Edit(int id)
    {
        var student = await _students.FindAsync(id);
        return student is null ? NotFound() : View(await FormAsync(student));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Edit(int id, [Bind(Prefix = "Student")] Student student)
    {
        if (id != student.Id)
            return BadRequest();
        if (!ModelState.IsValid)
            return View(await FormAsync(student));

        if (!await _students.UpdateAsync(student))
            return NotFound();

        TempData["Toast"] = "Изменения сохранены";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Delete(int id)
    {
        if (!await _students.DeleteAsync(id))
            return NotFound();

        TempData["Toast"] = "Студент удалён";
        return RedirectToAction(nameof(Index));
    }

    private async Task<StudentFormViewModel> FormAsync(Student student) => new()
    {
        Student = student,
        Groups = await _db.GroupOptionsAsync(student.GroupId)
    };
}
