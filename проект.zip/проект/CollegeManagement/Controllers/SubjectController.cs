using CollegeManagement.Data;
using CollegeManagement.Infrastructure;
using CollegeManagement.Models;
using CollegeManagement.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

public class SubjectController : Controller
{
    private readonly CollegeDbContext _db;

    public SubjectController(CollegeDbContext db) => _db = db;

    public async Task<IActionResult> Index()
    {
        var subjects = await _db.Subjects.AsNoTracking().Include(s => s.Teacher).ToListAsync();
        ViewBag.Averages = await _db.Grades
            .GroupBy(g => g.SubjectId)
            .Select(g => new { g.Key, Average = g.Average(x => (double)x.Value) })
            .ToDictionaryAsync(x => x.Key, x => (double?)x.Average);
        return View(subjects.OrderBy(s => s.Name, StringComparer.CurrentCulture).ToList());
    }

    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Create() => View(await FormAsync(new Subject()));

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Create([Bind(Prefix = "Subject")] Subject subject)
    {
        if (!ModelState.IsValid)
            return View(await FormAsync(subject));

        _db.Subjects.Add(subject);
        await _db.SaveChangesAsync();
        TempData["Toast"] = $"Предмет «{subject.Name}» добавлен";
        return RedirectToAction(nameof(Index));
    }

    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Edit(int id)
    {
        var subject = await _db.Subjects.FindAsync(id);
        return subject is null ? NotFound() : View(await FormAsync(subject));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Edit(int id, [Bind(Prefix = "Subject")] Subject subject)
    {
        if (id != subject.Id)
            return BadRequest();
        if (!ModelState.IsValid)
            return View(await FormAsync(subject));

        var existing = await _db.Subjects.FindAsync(id);
        if (existing is null)
            return NotFound();

        _db.Entry(existing).CurrentValues.SetValues(subject);
        await _db.SaveChangesAsync();
        TempData["Toast"] = "Изменения сохранены";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Delete(int id)
    {
        var subject = await _db.Subjects.FindAsync(id);
        if (subject is null)
            return NotFound();

        _db.Subjects.Remove(subject);
        await _db.SaveChangesAsync();
        TempData["Toast"] = "Предмет удалён вместе с оценками";
        return RedirectToAction(nameof(Index));
    }

    private async Task<SubjectFormViewModel> FormAsync(Subject subject) => new()
    {
        Subject = subject,
        Teachers = await _db.TeacherOptionsAsync(subject.TeacherId)
    };
}
