using CollegeManagement.Data;
using CollegeManagement.Infrastructure;
using CollegeManagement.Models;
using CollegeManagement.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

/// <summary>Электронный журнал: оценки группы по предмету.</summary>
public class GradeController : Controller
{
    private readonly CollegeDbContext _db;

    public GradeController(CollegeDbContext db) => _db = db;

    public async Task<IActionResult> Index(int? groupId, int? subjectId)
    {
        groupId ??= await _db.Groups.OrderBy(g => g.Course).ThenBy(g => g.Name).Select(g => (int?)g.Id).FirstOrDefaultAsync();
        subjectId ??= await _db.Subjects.OrderBy(s => s.Name).Select(s => (int?)s.Id).FirstOrDefaultAsync();
        return View(await BuildJournalAsync(groupId ?? 0, subjectId ?? 0));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind(Prefix = "NewGrade")] Grade grade, int groupId)
    {
        var studentInGroup = await _db.Students.AnyAsync(s => s.Id == grade.StudentId && s.GroupId == groupId);
        if (!studentInGroup)
            ModelState.AddModelError("NewGrade.StudentId", "Выберите студента из группы");

        if (!ModelState.IsValid)
        {
            var vm = await BuildJournalAsync(groupId, grade.SubjectId);
            vm.NewGrade = grade;
            return View(nameof(Index), vm);
        }

        grade.Date = grade.Date.Date;
        _db.Grades.Add(grade);
        await _db.SaveChangesAsync();
        TempData["Toast"] = $"Оценка {grade.Value} выставлена";
        return RedirectToAction(nameof(Index), new { groupId, subjectId = grade.SubjectId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var grade = await _db.Grades.Include(g => g.Student).FirstOrDefaultAsync(g => g.Id == id);
        if (grade is null)
            return NotFound();

        _db.Grades.Remove(grade);
        await _db.SaveChangesAsync();
        TempData["Toast"] = "Оценка удалена";
        return RedirectToAction(nameof(Index), new { groupId = grade.Student!.GroupId, subjectId = grade.SubjectId });
    }

    private async Task<GradeJournalViewModel> BuildJournalAsync(int groupId, int subjectId)
    {
        var vm = new GradeJournalViewModel
        {
            GroupId = groupId,
            SubjectId = subjectId,
            Groups = await _db.GroupOptionsAsync(groupId),
            Subjects = await _db.SubjectOptionsAsync(subjectId),
            NewGrade = new Grade { SubjectId = subjectId }
        };

        var group = await _db.Groups.AsNoTracking().FirstOrDefaultAsync(g => g.Id == groupId);
        var subject = await _db.Subjects.AsNoTracking().Include(s => s.Teacher).FirstOrDefaultAsync(s => s.Id == subjectId);
        if (group is null || subject is null)
            return vm;

        vm.GroupName = group.Name;
        vm.SubjectName = subject.Name;
        vm.TeacherName = subject.Teacher?.FullName;

        var students = await _db.Students.AsNoTracking().Where(s => s.GroupId == groupId).ToListAsync();
        var grades = await _db.Grades.AsNoTracking()
            .Where(g => g.SubjectId == subjectId && g.Student!.GroupId == groupId)
            .ToListAsync();

        vm.Dates = grades.Select(g => g.Date).Distinct().OrderBy(d => d).ToList();
        var byStudent = grades.ToLookup(g => g.StudentId);

        vm.Rows = students
            .OrderBy(s => s.LastName, StringComparer.CurrentCulture)
            .ThenBy(s => s.FirstName, StringComparer.CurrentCulture)
            .Select(s => new GradeJournalRow
            {
                StudentId = s.Id,
                FullName = s.FullName,
                Initials = s.Initials,
                ByDate = byStudent[s.Id].GroupBy(g => g.Date).ToDictionary(g => g.Key, g => g.ToList()),
                Average = byStudent[s.Id].Any() ? byStudent[s.Id].Average(g => g.Value) : null
            })
            .ToList();

        return vm;
    }
}
