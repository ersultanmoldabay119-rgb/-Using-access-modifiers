using System.Diagnostics;
using CollegeManagement.Models;
using CollegeManagement.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;

public class HomeController : Controller
{
    private readonly ReportManager _reports;

    public HomeController(ReportManager reports) => _reports = reports;

    public async Task<IActionResult> Index() => View(await _reports.GetDashboardAsync());

    [AllowAnonymous]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
