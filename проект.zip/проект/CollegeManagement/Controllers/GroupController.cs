using CollegeManagement.Data;
using CollegeManagement.Infrastructure;
using CollegeManagement.Models;
using CollegeManagement.Models.ViewModels;
using CollegeManagement.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

public class GroupController : Controller
{
    private readonly CollegeDbContext _db;
    private readonly ReportManager _reports;

    public GroupController(CollegeDbContext db, ReportManager reports)
    {
        _db = db;
        _reports = reports;
    }

    public async Task<IActionResult> Index()
    {
        var curators = await _db.Groups.AsNoTracking()
            .Where(g => g.Curator != null)
            .Select(g => new { g.Id, g.Curator })
            .ToListAsync();
        ViewBag.Curators = curators.ToDictionary(c => c.Id, c => c.Curator!.ShortName);
        return View(await _reports.GetGroupStatsAsync());
    }

    public async Task<IActionResult> Details(int id)
    {
        var details = await _reports.GetGroupDetailsAsync(id);
        return details is null ? NotFound() : View(details);
    }

    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Create() => View(await FormAsync(new Group()));

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Create([Bind(Prefix = "Group")] Group group)
    {
        await ValidateNameAsync(group);
        if (!ModelState.IsValid)
            return View(await FormAsync(group));

        _db.Groups.Add(group);
        await _db.SaveChangesAsync();
        TempData["Toast"] = $"Группа {group.Name} создана";
        return RedirectToAction(nameof(Details), new { id = group.Id });
    }

    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Edit(int id)
    {
        var group = await _db.Groups.FindAsync(id);
        return group is null ? NotFound() : View(await FormAsync(group));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Edit(int id, [Bind(Prefix = "Group")] Group group)
    {
        if (id != group.Id)
            return BadRequest();

        await ValidateNameAsync(group);
        if (!ModelState.IsValid)
            return View(await FormAsync(group));

        var existing = await _db.Groups.FindAsync(id);
        if (existing is null)
            return NotFound();

        _db.Entry(existing).CurrentValues.SetValues(group);
        await _db.SaveChangesAsync();
        TempData["Toast"] = "Изменения сохранены";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Delete(int id)
    {
        var group = await _db.Groups.Include(g => g.Students).FirstOrDefaultAsync(g => g.Id == id);
        if (group is null)
            return NotFound();

        if (group.Students.Count > 0)
        {
            TempData["Toast"] = "Нельзя удалить группу, в которой есть студенты";
            TempData["ToastKind"] = "error";
            return RedirectToAction(nameof(Details), new { id });
        }

        _db.Groups.Remove(group);
        await _db.SaveChangesAsync();
        TempData["Toast"] = $"Группа {group.Name} удалена";
        return RedirectToAction(nameof(Index));
    }

    private async Task ValidateNameAsync(Group group)
    {
        group.Name = group.Name?.Trim().ToUpper() ?? string.Empty;
        if (await _db.Groups.AnyAsync(g => g.Name == group.Name && g.Id != group.Id))
            ModelState.AddModelError("Group.Name", "Группа с таким названием уже есть");
    }

    private async Task<GroupFormViewModel> FormAsync(Group group) => new()
    {
        Group = group,
        Teachers = await _db.TeacherOptionsAsync(group.CuratorId)
    };
}
