using CollegeManagement.Data;
using CollegeManagement.Infrastructure;
using CollegeManagement.Models.ViewModels;
using CollegeManagement.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

public class AttendanceController : Controller
{
    private readonly CollegeDbContext _db;
    private readonly AttendanceManager _attendance;

    public AttendanceController(CollegeDbContext db, AttendanceManager attendance)
    {
        _db = db;
        _attendance = attendance;
    }

    /// <summary>Ведомость посещаемости группы за день.</summary>
    public async Task<IActionResult> Index(int? groupId, DateTime? date)
    {
        groupId ??= await FirstGroupIdAsync();
        var day = (date ?? DateTime.Today).Date;

        var vm = new AttendanceSheetViewModel
        {
            GroupId = groupId ?? 0,
            Date = day,
            Groups = await _db.GroupOptionsAsync(groupId),
            GroupName = await _db.Groups.Where(g => g.Id == groupId).Select(g => g.Name).FirstOrDefaultAsync(),
            Rows = groupId is > 0 ? await _attendance.GetSheetAsync(groupId.Value, day) : new()
        };
        return View(vm);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(AttendanceSheetViewModel model)
    {
        if (model.Date.Date > DateTime.Today)
        {
            TempData["Toast"] = "Нельзя отмечать посещаемость на будущую дату";
            TempData["ToastKind"] = "error";
        }
        else
        {
            await _attendance.SaveSheetAsync(model.GroupId, model.Date, model.Rows);
            TempData["Toast"] = $"Посещаемость за {model.Date:d MMMM} сохранена";
        }
        return RedirectToAction(nameof(Index), new { groupId = model.GroupId, date = model.Date.ToString("yyyy-MM-dd") });
    }

    /// <summary>Отчёт по посещаемости группы за период.</summary>
    public async Task<IActionResult> Report(int? groupId, DateTime? from, DateTime? to)
    {
        groupId ??= await FirstGroupIdAsync();
        var end = (to ?? DateTime.Today).Date;
        var start = (from ?? end.AddDays(-27)).Date;
        if (start > end)
            (start, end) = (end, start);

        var vm = new AttendanceReportViewModel
        {
            GroupId = groupId ?? 0,
            From = start,
            To = end,
            Groups = await _db.GroupOptionsAsync(groupId),
            GroupName = await _db.Groups.Where(g => g.Id == groupId).Select(g => g.Name).FirstOrDefaultAsync()
        };

        if (groupId is > 0)
        {
            (vm.Days, vm.Students) = await _attendance.GetGroupReportAsync(groupId.Value, start, end);
            vm.Total = new AttendanceSummary
            {
                Present = vm.Students.Sum(s => s.Summary.Present),
                Late = vm.Students.Sum(s => s.Summary.Late),
                Absent = vm.Students.Sum(s => s.Summary.Absent),
                Excused = vm.Students.Sum(s => s.Summary.Excused),
            };
        }
        return View(vm);
    }

    private Task<int?> FirstGroupIdAsync() =>
        _db.Groups.OrderBy(g => g.Course).ThenBy(g => g.Name).Select(g => (int?)g.Id).FirstOrDefaultAsync();
}
