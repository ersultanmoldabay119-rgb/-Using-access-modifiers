using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

public class TeacherController : Controller
{
    private readonly CollegeDbContext _db;

    public TeacherController(CollegeDbContext db) => _db = db;

    public async Task<IActionResult> Index(string? search)
    {
        var teachers = await _db.Teachers.AsNoTracking()
            .Include(t => t.Subjects)
            .Include(t => t.CuratedGroups)
            .ToListAsync();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            teachers = teachers.Where(t => t.FullName.Contains(term, StringComparison.CurrentCultureIgnoreCase)
                                           || t.Subjects.Any(s => s.Name.Contains(term, StringComparison.CurrentCultureIgnoreCase)))
                               .ToList();
        }

        ViewBag.Search = search;
        return View(teachers.OrderBy(t => t.LastName, StringComparer.CurrentCulture).ToList());
    }

    [Authorize(Roles = Roles.Admin)]
    public IActionResult Create() => View(new Teacher());

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Create(Teacher teacher)
    {
        if (!ModelState.IsValid)
            return View(teacher);

        _db.Teachers.Add(teacher);
        await _db.SaveChangesAsync();
        TempData["Toast"] = $"Преподаватель {teacher.ShortName} добавлен";
        return RedirectToAction(nameof(Index));
    }

    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Edit(int id)
    {
        var teacher = await _db.Teachers.FindAsync(id);
        return teacher is null ? NotFound() : View(teacher);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Edit(int id, Teacher teacher)
    {
        if (id != teacher.Id)
            return BadRequest();
        if (!ModelState.IsValid)
            return View(teacher);

        var existing = await _db.Teachers.FindAsync(id);
        if (existing is null)
            return NotFound();

        _db.Entry(existing).CurrentValues.SetValues(teacher);
        await _db.SaveChangesAsync();
        TempData["Toast"] = "Изменения сохранены";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Delete(int id)
    {
        var teacher = await _db.Teachers.FindAsync(id);
        if (teacher is null)
            return NotFound();

        // Предметы и группы остаются, у них просто сбрасывается преподаватель/куратор.
        _db.Teachers.Remove(teacher);
        await _db.SaveChangesAsync();
        TempData["Toast"] = "Преподаватель удалён";
        return RedirectToAction(nameof(Index));
    }
}
