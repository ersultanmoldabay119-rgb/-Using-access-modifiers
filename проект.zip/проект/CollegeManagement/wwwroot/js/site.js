﻿(() => {
    const root = document.documentElement;

    // Переключение светлой/тёмной темы
    document.querySelectorAll('[data-theme-toggle]').forEach(btn => btn.addEventListener('click', () => {
        const isDark = root.dataset.theme
            ? root.dataset.theme === 'dark'
            : matchMedia('(prefers-color-scheme: dark)').matches;
        root.dataset.theme = isDark ? 'light' : 'dark';
        try { localStorage.setItem('theme', root.dataset.theme); } catch { }
    }));

    // Мобильное меню
    document.querySelectorAll('[data-open-sidebar]').forEach(b => b.addEventListener('click', () => document.body.classList.add('sidebar-open')));
    document.querySelectorAll('[data-close-sidebar]').forEach(b => b.addEventListener('click', () => document.body.classList.remove('sidebar-open')));

    // Тень у верхней панели при прокрутке
    const topbar = document.querySelector('.topbar');
    if (topbar) {
        const onScroll = () => topbar.classList.toggle('scrolled', scrollY > 4);
        addEventListener('scroll', onScroll, { passive: true });
        onScroll();
    }

    // «/» — фокус на поиске
    addEventListener('keydown', e => {
        if (e.key !== '/' || ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName)) return;
        const input = document.querySelector('.search input');
        if (input) { e.preventDefault(); input.focus(); }
    });

    // Кликабельные строки таблиц
    document.querySelectorAll('tr[data-href]').forEach(tr => tr.addEventListener('click', e => {
        if (e.target.closest('a, button, form, input, select')) return;
        location.href = tr.dataset.href;
    }));

    // Подтверждение удаления
    document.querySelectorAll('form[data-confirm]').forEach(f => f.addEventListener('submit', e => {
        if (!confirm(f.dataset.confirm)) e.preventDefault();
    }));

    // Автоотправка фильтров
    document.querySelectorAll('[data-autosubmit]').forEach(el => el.addEventListener('change', () => el.form.submit()));

    // Ведомость посещаемости: подсветка строк и массовые отметки
    const sheet = document.querySelector('[data-sheet]');
    if (sheet) {
        const counters = document.querySelectorAll('[data-count]');
        const refresh = () => {
            const counts = { Present: 0, Late: 0, Absent: 0, Excused: 0 };
            sheet.querySelectorAll('.sheet-row').forEach(row => {
                const checked = row.querySelector('input[type=radio]:checked');
                const value = checked ? checked.value : '';
                if (value in counts) counts[value]++;
                row.classList.toggle('is-absent', value === 'Absent');
                row.classList.toggle('is-late', value === 'Late');
            });
            counters.forEach(c => c.textContent = counts[c.dataset.count]);
        };
        sheet.addEventListener('change', refresh);
        document.querySelectorAll('[data-mark-all]').forEach(btn => btn.addEventListener('click', () => {
            sheet.querySelectorAll(`input[value="${btn.dataset.markAll}"]`).forEach(r => r.checked = true);
            refresh();
        }));
        refresh();
    }

    // Демо-учётки на странице входа
    document.querySelectorAll('[data-fill]').forEach(b => b.addEventListener('click', () => {
        const [u, p] = b.dataset.fill.split(':');
        document.querySelector('#Username').value = u;
        document.querySelector('#Password').value = p;
    }));
})();
