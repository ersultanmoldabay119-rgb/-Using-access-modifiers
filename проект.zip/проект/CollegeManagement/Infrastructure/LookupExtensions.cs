using CollegeManagement.Data;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Infrastructure;

/// <summary>Списки для выпадающих меню.</summary>
public static class LookupExtensions
{
    public static async Task<List<SelectListItem>> GroupOptionsAsync(this CollegeDbContext db, int? selected = null)
    {
        var groups = await db.Groups.AsNoTracking().OrderBy(g => g.Course).ThenBy(g => g.Name).ToListAsync();
        return groups
            .Select(g => new SelectListItem($"{g.Name} · {g.Course} курс", g.Id.ToString(), g.Id == selected))
            .ToList();
    }

    public static async Task<List<SelectListItem>> TeacherOptionsAsync(this CollegeDbContext db, int? selected = null)
    {
        var teachers = await db.Teachers.AsNoTracking().ToListAsync();
        return teachers
            .OrderBy(t => t.LastName, StringComparer.CurrentCulture)
            .Select(t => new SelectListItem(t.FullName, t.Id.ToString(), t.Id == selected))
            .ToList();
    }

    public static async Task<List<SelectListItem>> SubjectOptionsAsync(this CollegeDbContext db, int? selected = null)
    {
        var subjects = await db.Subjects.AsNoTracking().ToListAsync();
        return subjects
            .OrderBy(s => s.Name, StringComparer.CurrentCulture)
            .Select(s => new SelectListItem(s.Name, s.Id.ToString(), s.Id == selected))
            .ToList();
    }
}
