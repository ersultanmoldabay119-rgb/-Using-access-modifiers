using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Reflection;
using System.Text;
using CollegeManagement.Models;

namespace CollegeManagement.Infrastructure;

/// <summary>Помощники для представлений: форматирование, цветовые классы, построение SVG-графиков.</summary>
public static class Ui
{
    private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

    /// <summary>Число для CSS/SVG — всегда с точкой, независимо от культуры.</summary>
    public static string Num(double value) => Math.Round(value, 2).ToString(Inv);

    public static string Avg(double? value) => value?.ToString("0.00") ?? "—";

    public static string Pct(double? value) => value is null ? "—" : $"{value:0}%";

    /// <summary>Оттенок аватара, стабильный для конкретного id.</summary>
    public static int Hue(int id) => (id * 47 + 210) % 360;

    public static string GradeTone(double? avg) => avg switch
    {
        null => "muted",
        >= 4.5 => "good",
        >= 3.5 => "ok",
        >= 3.0 => "warn",
        _ => "bad"
    };

    public static string RateTone(double? rate) => rate switch
    {
        null => "muted",
        >= 92 => "good",
        >= 85 => "ok",
        >= 80 => "warn",
        _ => "bad"
    };

    public static string StatusClass(AttendanceStatus s) => s switch
    {
        AttendanceStatus.Present => "present",
        AttendanceStatus.Late => "late",
        AttendanceStatus.Absent => "absent",
        _ => "excused"
    };

    public static string StatusShort(AttendanceStatus s) => s switch
    {
        AttendanceStatus.Present => "П",
        AttendanceStatus.Late => "О",
        AttendanceStatus.Absent => "Н",
        _ => "У"
    };

    public static string DisplayName(this Enum value) =>
        value.GetType().GetMember(value.ToString()).FirstOrDefault()?
            .GetCustomAttribute<DisplayAttribute>()?.GetName() ?? value.ToString();

    public static string Plural(int n, string one, string few, string many)
    {
        var mod100 = n % 100;
        var mod10 = n % 10;
        var word = mod100 is >= 11 and <= 14 ? many
            : mod10 == 1 ? one
            : mod10 is >= 2 and <= 4 ? few
            : many;
        return $"{n} {word}";
    }

    public static string Greeting()
    {
        var h = DateTime.Now.Hour;
        return h < 5 ? "Доброй ночи" : h < 12 ? "Доброе утро" : h < 18 ? "Добрый день" : "Добрый вечер";
    }

    public static string Capitalize(string s) => s.Length == 0 ? s : char.ToUpper(s[0]) + s[1..];

    /// <summary>
    /// Строит линию и заливку для простого графика.
    /// Возвращает path для линии, path для области под ней и координаты точек.
    /// </summary>
    public static (string Line, string Area, List<(double X, double Y)> Points) LineChart(
        IReadOnlyList<double> values, double width, double height, double min, double max, double padX = 0)
    {
        var points = new List<(double X, double Y)>();
        if (values.Count == 0)
            return ("", "", points);

        var step = values.Count > 1 ? (width - padX * 2) / (values.Count - 1) : 0;
        for (var i = 0; i < values.Count; i++)
        {
            var v = Math.Clamp(values[i], min, max);
            points.Add((padX + i * step, height - (v - min) / (max - min) * height));
        }

        var line = new StringBuilder();
        for (var i = 0; i < points.Count; i++)
            line.Append(i == 0 ? "M" : " L").Append(Num(points[i].X)).Append(' ').Append(Num(points[i].Y));

        var area = $"{line} L{Num(points[^1].X)} {Num(height)} L{Num(points[0].X)} {Num(height)} Z";
        return (line.ToString(), area, points);
    }
}
