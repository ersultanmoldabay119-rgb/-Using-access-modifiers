using CollegeManagement.Data;
using CollegeManagement.Models.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Services;

/// <summary>Сводные отчёты: дашборд, статистика по группам.</summary>
public class ReportManager
{
    private const double RiskAverage = 3.3;
    private const double RiskAttendance = 80;

    private readonly CollegeDbContext _db;
    private readonly StudentService _students;
    private readonly AttendanceManager _attendance;

    public ReportManager(CollegeDbContext db, StudentService students, AttendanceManager attendance)
    {
        _db = db;
        _students = students;
        _attendance = attendance;
    }

    public async Task<DashboardViewModel> GetDashboardAsync()
    {
        var vm = new DashboardViewModel
        {
            StudentsCount = await _db.Students.CountAsync(),
            TeachersCount = await _db.Teachers.CountAsync(),
            GroupsCount = await _db.Groups.CountAsync(),
            SubjectsCount = await _db.Subjects.CountAsync(),
            AverageGrade = await _db.Grades.Select(g => (double?)g.Value).AverageAsync(),
        };

        var lastDay = await _attendance.GetLastMarkedDayAsync();
        if (lastDay is { } day)
        {
            vm.LastDay = day;
            vm.LastDaySummary = await _attendance.GetSummaryForDayAsync(day);
            vm.Trend = await _attendance.GetDailyRatesAsync(day.AddDays(-27), day);
            if (vm.Trend.Count >= 2)
                vm.RateDelta = vm.Trend[^1].Rate - vm.Trend[^2].Rate;
        }

        var stats = await _students.GetStatsAsync(_db.Students);
        vm.Groups = await GetGroupStatsAsync(stats);

        vm.TopStudents = stats
            .Where(s => s.GradesCount >= 3)
            .OrderByDescending(s => s.Average)
            .ThenByDescending(s => s.AttendanceRate)
            .Take(5)
            .ToList();

        vm.AtRisk = stats
            .Where(s => s.Average < RiskAverage || s.AttendanceRate < RiskAttendance)
            .OrderBy(s => Math.Min((s.Average ?? 5) / 5, (s.AttendanceRate ?? 100) / 100))
            .Take(5)
            .ToList();

        vm.GradeDistribution = await _db.Grades
            .GroupBy(g => g.Value)
            .Select(g => new { g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.Key, x => x.Count);

        vm.RecentGrades = await _db.Grades.AsNoTracking()
            .Include(g => g.Student)
            .Include(g => g.Subject)
            .OrderByDescending(g => g.Date).ThenByDescending(g => g.Id)
            .Take(6)
            .ToListAsync();

        return vm;
    }

    public async Task<List<GroupStat>> GetGroupStatsAsync(List<StudentStat>? stats = null)
    {
        stats ??= await _students.GetStatsAsync(_db.Students);
        var byGroup = stats.ToLookup(s => s.GroupId);
        var groups = await _db.Groups.AsNoTracking().ToListAsync();

        return groups
            .OrderBy(g => g.Course).ThenBy(g => g.Name, StringComparer.CurrentCulture)
            .Select(g => ToGroupStat(g.Id, g.Name, g.Specialty, g.Course, byGroup[g.Id].ToList()))
            .ToList();
    }

    public async Task<GroupDetailsViewModel?> GetGroupDetailsAsync(int id)
    {
        var group = await _db.Groups.AsNoTracking().Include(g => g.Curator).FirstOrDefaultAsync(g => g.Id == id);
        if (group is null)
            return null;

        var students = await _students.GetStatsAsync(_db.Students.Where(s => s.GroupId == id));

        var subjectAverages = await _db.Grades
            .Where(g => g.Student!.GroupId == id)
            .GroupBy(g => g.SubjectId)
            .Select(g => new { SubjectId = g.Key, Average = g.Average(x => (double)x.Value) })
            .ToListAsync();
        var subjectNames = await _db.Subjects.ToDictionaryAsync(s => s.Id, s => s.Name);

        var lastDay = await _attendance.GetLastMarkedDayAsync() ?? DateTime.Today;

        return new GroupDetailsViewModel
        {
            Group = group,
            Stat = ToGroupStat(group.Id, group.Name, group.Specialty, group.Course, students),
            Students = students,
            SubjectAverages = subjectAverages
                .Select(s => (subjectNames.GetValueOrDefault(s.SubjectId, "—"), s.Average))
                .OrderByDescending(s => s.Average)
                .ToList(),
            Trend = await _attendance.GetDailyRatesAsync(lastDay.AddDays(-27), lastDay, id)
        };
    }

    private static GroupStat ToGroupStat(int id, string name, string specialty, int course, List<StudentStat> students)
    {
        var averages = students.Where(s => s.Average.HasValue).Select(s => s.Average!.Value).ToList();
        var rates = students.Where(s => s.AttendanceRate.HasValue).Select(s => s.AttendanceRate!.Value).ToList();
        return new GroupStat(id, name, specialty, course, students.Count,
            averages.Count > 0 ? averages.Average() : null,
            rates.Count > 0 ? rates.Average() : null);
    }
}
