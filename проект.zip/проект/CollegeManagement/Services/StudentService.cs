using CollegeManagement.Data;
using CollegeManagement.Models;
using CollegeManagement.Models.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Services;

public class StudentService
{
    private readonly CollegeDbContext _db;

    public StudentService(CollegeDbContext db) => _db = db;

    /// <summary>Средний балл и посещаемость для набора студентов, отсортированных по ФИО.</summary>
    public async Task<List<StudentStat>> GetStatsAsync(IQueryable<Student> query)
    {
        var students = await query.AsNoTracking().Include(s => s.Group).ToListAsync();
        var ids = students.Select(s => s.Id).ToList();

        var grades = await _db.Grades
            .Where(g => ids.Contains(g.StudentId))
            .GroupBy(g => g.StudentId)
            .Select(g => new { StudentId = g.Key, Average = g.Average(x => (double)x.Value), Count = g.Count() })
            .ToDictionaryAsync(x => x.StudentId);

        var attendance = await _db.Attendance
            .Where(a => ids.Contains(a.StudentId))
            .GroupBy(a => a.StudentId)
            .Select(g => new
            {
                StudentId = g.Key,
                Total = g.Count(),
                Attended = g.Count(a => a.Status == AttendanceStatus.Present || a.Status == AttendanceStatus.Late)
            })
            .ToDictionaryAsync(x => x.StudentId);

        return students
            .OrderBy(s => s.LastName, StringComparer.CurrentCulture)
            .ThenBy(s => s.FirstName, StringComparer.CurrentCulture)
            .Select(s =>
            {
                grades.TryGetValue(s.Id, out var g);
                attendance.TryGetValue(s.Id, out var a);
                return new StudentStat(
                    s.Id, s.FullName, s.Initials, s.GroupId, s.Group?.Name ?? "—",
                    g?.Average, g?.Count ?? 0,
                    a is { Total: > 0 } ? a.Attended * 100.0 / a.Total : null);
            })
            .ToList();
    }

    public async Task<List<StudentStat>> GetListAsync(string? search, int? groupId)
    {
        var query = _db.Students.AsQueryable();
        if (groupId is > 0)
            query = query.Where(s => s.GroupId == groupId);

        var list = await GetStatsAsync(query);

        // SQLite не умеет регистронезависимо сравнивать кириллицу, поэтому фильтруем в памяти.
        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            list = list.Where(s => s.FullName.Contains(term, StringComparison.CurrentCultureIgnoreCase)
                                   || s.GroupName.Contains(term, StringComparison.CurrentCultureIgnoreCase))
                       .ToList();
        }
        return list;
    }

    public async Task<StudentProfileViewModel?> GetProfileAsync(int id)
    {
        var student = await _db.Students.AsNoTracking()
            .Include(s => s.Group).ThenInclude(g => g!.Curator)
            .FirstOrDefaultAsync(s => s.Id == id);
        if (student is null)
            return null;

        var grades = await _db.Grades.AsNoTracking()
            .Include(g => g.Subject).ThenInclude(s => s!.Teacher)
            .Where(g => g.StudentId == id)
            .OrderBy(g => g.Date)
            .ToListAsync();

        var attendance = await _db.Attendance.AsNoTracking()
            .Where(a => a.StudentId == id)
            .OrderBy(a => a.Date)
            .ToListAsync();

        var groupmates = await GetStatsAsync(_db.Students.Where(s => s.GroupId == student.GroupId));
        var ranked = groupmates.Where(s => s.Average.HasValue).OrderByDescending(s => s.Average).ToList();
        var rank = ranked.FindIndex(s => s.Id == id);

        return new StudentProfileViewModel
        {
            Student = student,
            Average = grades.Count > 0 ? grades.Average(g => g.Value) : null,
            RankInGroup = rank >= 0 ? rank + 1 : null,
            GroupSize = groupmates.Count,
            Attendance = AttendanceManager.Summarize(attendance),
            RecentAttendance = attendance.TakeLast(20).ToList(),
            Subjects = grades
                .GroupBy(g => g.SubjectId)
                .Select(gr => new SubjectProgress(
                    gr.Key,
                    gr.First().Subject!.Name,
                    gr.First().Subject!.Teacher?.ShortName,
                    gr.Average(g => g.Value),
                    gr.ToList()))
                .OrderBy(s => s.SubjectName, StringComparer.CurrentCulture)
                .ToList()
        };
    }

    public Task<Student?> FindAsync(int id) => _db.Students.FirstOrDefaultAsync(s => s.Id == id);

    public async Task CreateAsync(Student student)
    {
        _db.Students.Add(student);
        await _db.SaveChangesAsync();
    }

    public async Task<bool> UpdateAsync(Student student)
    {
        var existing = await _db.Students.FindAsync(student.Id);
        if (existing is null)
            return false;

        _db.Entry(existing).CurrentValues.SetValues(student);
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var student = await _db.Students.FindAsync(id);
        if (student is null)
            return false;

        _db.Students.Remove(student);
        await _db.SaveChangesAsync();
        return true;
    }
}
