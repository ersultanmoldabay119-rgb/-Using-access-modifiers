using CollegeManagement.Data;
using CollegeManagement.Models;
using CollegeManagement.Models.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Services;

public class AttendanceManager
{
    private readonly CollegeDbContext _db;

    public AttendanceManager(CollegeDbContext db) => _db = db;

    public static AttendanceSummary Summarize(IEnumerable<Attendance> records) => Summarize(records.Select(r => r.Status));

    public static AttendanceSummary Summarize(IEnumerable<AttendanceStatus> statuses)
    {
        var summary = new AttendanceSummary();
        foreach (var status in statuses)
        {
            switch (status)
            {
                case AttendanceStatus.Present: summary.Present++; break;
                case AttendanceStatus.Late: summary.Late++; break;
                case AttendanceStatus.Absent: summary.Absent++; break;
                case AttendanceStatus.Excused: summary.Excused++; break;
            }
        }
        return summary;
    }

    public Task<DateTime?> GetLastMarkedDayAsync() =>
        _db.Attendance.OrderByDescending(a => a.Date).Select(a => (DateTime?)a.Date).FirstOrDefaultAsync();

    public async Task<AttendanceSummary> GetSummaryForDayAsync(DateTime date, int? groupId = null)
    {
        var query = _db.Attendance.Where(a => a.Date == date.Date);
        if (groupId is > 0)
            query = query.Where(a => a.Student!.GroupId == groupId);

        return Summarize(await query.Select(a => a.Status).ToListAsync());
    }

    /// <summary>Процент присутствующих по дням за период.</summary>
    public async Task<List<DayRate>> GetDailyRatesAsync(DateTime from, DateTime to, int? groupId = null)
    {
        var query = _db.Attendance.Where(a => a.Date >= from.Date && a.Date <= to.Date);
        if (groupId is > 0)
            query = query.Where(a => a.Student!.GroupId == groupId);

        var rows = await query.Select(a => new { a.Date, a.Status }).ToListAsync();
        return rows
            .GroupBy(r => r.Date)
            .OrderBy(g => g.Key)
            .Select(g => new DayRate(g.Key, Summarize(g.Select(r => r.Status)).Rate ?? 0))
            .ToList();
    }

    public async Task<List<AttendanceRow>> GetSheetAsync(int groupId, DateTime date)
    {
        var students = await _db.Students.AsNoTracking().Where(s => s.GroupId == groupId).ToListAsync();
        var marks = await _db.Attendance
            .Where(a => a.Date == date.Date && a.Student!.GroupId == groupId)
            .ToDictionaryAsync(a => a.StudentId, a => a.Status);

        return students
            .OrderBy(s => s.LastName, StringComparer.CurrentCulture)
            .ThenBy(s => s.FirstName, StringComparer.CurrentCulture)
            .Select(s => new AttendanceRow
            {
                StudentId = s.Id,
                FullName = s.FullName,
                Initials = s.Initials,
                IsMarked = marks.ContainsKey(s.Id),
                Status = marks.TryGetValue(s.Id, out var status) ? status : AttendanceStatus.Present
            })
            .ToList();
    }

    /// <summary>Сохраняет отметки за день: обновляет существующие и добавляет новые.</summary>
    public async Task SaveSheetAsync(int groupId, DateTime date, IEnumerable<AttendanceRow> rows)
    {
        date = date.Date;
        var studentIds = await _db.Students.Where(s => s.GroupId == groupId).Select(s => s.Id).ToListAsync();
        var existing = await _db.Attendance
            .Where(a => a.Date == date && studentIds.Contains(a.StudentId))
            .ToDictionaryAsync(a => a.StudentId);

        foreach (var row in rows.Where(r => studentIds.Contains(r.StudentId)))
        {
            if (existing.TryGetValue(row.StudentId, out var record))
                record.Status = row.Status;
            else
                _db.Attendance.Add(new Attendance { StudentId = row.StudentId, Date = date, Status = row.Status });
        }

        await _db.SaveChangesAsync();
    }

    public async Task<(List<DateTime> Days, List<StudentAttendanceStat> Students)> GetGroupReportAsync(int groupId, DateTime from, DateTime to)
    {
        var students = await _db.Students.AsNoTracking().Where(s => s.GroupId == groupId).ToListAsync();
        var records = await _db.Attendance.AsNoTracking()
            .Where(a => a.Student!.GroupId == groupId && a.Date >= from.Date && a.Date <= to.Date)
            .ToListAsync();

        var days = records.Select(r => r.Date).Distinct().OrderBy(d => d).ToList();
        var byStudent = records.ToLookup(r => r.StudentId);

        var stats = students
            .OrderBy(s => s.LastName, StringComparer.CurrentCulture)
            .ThenBy(s => s.FirstName, StringComparer.CurrentCulture)
            .Select(s => new StudentAttendanceStat(
                s.Id, s.FullName, s.Initials,
                Summarize(byStudent[s.Id]),
                byStudent[s.Id].OrderBy(r => r.Date).ToList()))
            .ToList();

        return (days, stats);
    }
}
