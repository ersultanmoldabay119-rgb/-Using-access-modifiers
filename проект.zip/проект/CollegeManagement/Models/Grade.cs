using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models;

public enum GradeType
{
    [Display(Name = "Текущая")] Current,
    [Display(Name = "Контрольная")] Test,
    [Display(Name = "Экзамен")] Exam
}

public class Grade
{
    public int Id { get; set; }

    [Display(Name = "Студент")]
    [Range(1, int.MaxValue, ErrorMessage = "Выберите студента")]
    public int StudentId { get; set; }
    public Student? Student { get; set; }

    [Display(Name = "Предмет")]
    [Range(1, int.MaxValue, ErrorMessage = "Выберите предмет")]
    public int SubjectId { get; set; }
    public Subject? Subject { get; set; }

    [Display(Name = "Оценка")]
    [Range(2, 5, ErrorMessage = "Оценка от 2 до 5")]
    public int Value { get; set; } = 5;

    [Display(Name = "Тип")]
    public GradeType Type { get; set; } = GradeType.Current;

    [Display(Name = "Дата")]
    [DataType(DataType.Date)]
    public DateTime Date { get; set; } = DateTime.Today;

    [Display(Name = "Комментарий")]
    [StringLength(200)]
    public string? Comment { get; set; }
}
