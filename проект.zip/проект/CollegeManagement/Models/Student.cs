using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models;

public class Student : Person
{
    [Display(Name = "Группа")]
    [Range(1, int.MaxValue, ErrorMessage = "Выберите группу")]
    public int GroupId { get; set; }
    public Group? Group { get; set; }

    [Display(Name = "Дата зачисления")]
    [DataType(DataType.Date)]
    public DateTime EnrollmentDate { get; set; } = DateTime.Today;

    public List<Grade> Grades { get; set; } = new();
    public List<Attendance> AttendanceRecords { get; set; } = new();
}
