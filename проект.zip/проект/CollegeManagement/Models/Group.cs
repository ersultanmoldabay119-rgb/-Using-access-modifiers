using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models;

public class Group
{
    public int Id { get; set; }

    [Display(Name = "Название")]
    [Required(ErrorMessage = "Укажите название группы")]
    [StringLength(20)]
    public string Name { get; set; } = string.Empty;

    [Display(Name = "Специальность")]
    [Required(ErrorMessage = "Укажите специальность")]
    [StringLength(120)]
    public string Specialty { get; set; } = string.Empty;

    [Display(Name = "Курс")]
    [Range(1, 4, ErrorMessage = "Курс от 1 до 4")]
    public int Course { get; set; } = 1;

    [Display(Name = "Куратор")]
    public int? CuratorId { get; set; }
    public Teacher? Curator { get; set; }

    public List<Student> Students { get; set; } = new();
}
