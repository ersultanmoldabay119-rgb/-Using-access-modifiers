using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models;

public enum AttendanceStatus
{
    [Display(Name = "Присутствовал")] Present,
    [Display(Name = "Опоздал")] Late,
    [Display(Name = "Отсутствовал")] Absent,
    [Display(Name = "Уважительная")] Excused
}

/// <summary>Отметка посещаемости студента за учебный день.</summary>
public class Attendance
{
    public int Id { get; set; }

    public int StudentId { get; set; }
    public Student? Student { get; set; }

    [DataType(DataType.Date)]
    public DateTime Date { get; set; }

    public AttendanceStatus Status { get; set; }
}
