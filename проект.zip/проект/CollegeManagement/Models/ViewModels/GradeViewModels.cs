using Microsoft.AspNetCore.Mvc.Rendering;

namespace CollegeManagement.Models.ViewModels;

public class GradeJournalRow
{
    public int StudentId { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Initials { get; set; } = string.Empty;
    public Dictionary<DateTime, List<Grade>> ByDate { get; set; } = new();
    public double? Average { get; set; }
}

public class GradeJournalViewModel
{
    public int GroupId { get; set; }
    public int SubjectId { get; set; }
    public string? GroupName { get; set; }
    public string? SubjectName { get; set; }
    public string? TeacherName { get; set; }
    public List<DateTime> Dates { get; set; } = new();
    public List<GradeJournalRow> Rows { get; set; } = new();
    public List<SelectListItem> Groups { get; set; } = new();
    public List<SelectListItem> Subjects { get; set; } = new();
    public Grade NewGrade { get; set; } = new();
}
