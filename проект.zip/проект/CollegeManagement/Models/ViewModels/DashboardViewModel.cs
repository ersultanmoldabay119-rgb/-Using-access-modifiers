namespace CollegeManagement.Models.ViewModels;

public record GroupStat(int Id, string Name, string Specialty, int Course, int StudentsCount, double? Average, double? AttendanceRate);

public class DashboardViewModel
{
    public int StudentsCount { get; set; }
    public int TeachersCount { get; set; }
    public int GroupsCount { get; set; }
    public int SubjectsCount { get; set; }
    public double? AverageGrade { get; set; }

    /// <summary>Последний день, за который есть отметки посещаемости.</summary>
    public DateTime? LastDay { get; set; }
    public AttendanceSummary LastDaySummary { get; set; } = new();
    public double? RateDelta { get; set; }

    public List<DayRate> Trend { get; set; } = new();
    public List<GroupStat> Groups { get; set; } = new();
    public List<StudentStat> TopStudents { get; set; } = new();
    public List<StudentStat> AtRisk { get; set; } = new();

    /// <summary>Количество оценок 5, 4, 3, 2.</summary>
    public Dictionary<int, int> GradeDistribution { get; set; } = new();
    public List<Grade> RecentGrades { get; set; } = new();
}
