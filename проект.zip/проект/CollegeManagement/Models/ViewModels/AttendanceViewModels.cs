using Microsoft.AspNetCore.Mvc.Rendering;

namespace CollegeManagement.Models.ViewModels;

public class AttendanceSummary
{
    public int Present { get; set; }
    public int Late { get; set; }
    public int Absent { get; set; }
    public int Excused { get; set; }

    public int Total => Present + Late + Absent + Excused;

    /// <summary>Доля дней, когда студент был на занятиях (включая опоздания), в процентах.</summary>
    public double? Rate => Total == 0 ? null : (Present + Late) * 100.0 / Total;
}

public record DayRate(DateTime Date, double Rate);

public class AttendanceRow
{
    public int StudentId { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Initials { get; set; } = string.Empty;
    public AttendanceStatus Status { get; set; } = AttendanceStatus.Present;
    public bool IsMarked { get; set; }
}

public class AttendanceSheetViewModel
{
    public int GroupId { get; set; }
    public DateTime Date { get; set; } = DateTime.Today;
    public List<AttendanceRow> Rows { get; set; } = new();
    public List<SelectListItem> Groups { get; set; } = new();
    public string? GroupName { get; set; }
    public bool IsMarked => Rows.Any(r => r.IsMarked);
}

public record StudentAttendanceStat(int StudentId, string FullName, string Initials, AttendanceSummary Summary, List<Attendance> Days);

public class AttendanceReportViewModel
{
    public int GroupId { get; set; }
    public string? GroupName { get; set; }
    public DateTime From { get; set; }
    public DateTime To { get; set; }
    public List<DateTime> Days { get; set; } = new();
    public List<StudentAttendanceStat> Students { get; set; } = new();
    public List<SelectListItem> Groups { get; set; } = new();
    public AttendanceSummary Total { get; set; } = new();
}
