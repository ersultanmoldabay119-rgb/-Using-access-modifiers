using Microsoft.AspNetCore.Mvc.Rendering;

namespace CollegeManagement.Models.ViewModels;

public class GroupDetailsViewModel
{
    public Group Group { get; set; } = null!;
    public GroupStat Stat { get; set; } = null!;
    public List<StudentStat> Students { get; set; } = new();
    public List<(string Subject, double Average)> SubjectAverages { get; set; } = new();
    public List<DayRate> Trend { get; set; } = new();
}

public class GroupFormViewModel
{
    public Group Group { get; set; } = new();
    public List<SelectListItem> Teachers { get; set; } = new();
}

public class SubjectFormViewModel
{
    public Subject Subject { get; set; } = new();
    public List<SelectListItem> Teachers { get; set; } = new();
}
