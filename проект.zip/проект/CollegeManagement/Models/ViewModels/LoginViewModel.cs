using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models.ViewModels;

public class LoginViewModel
{
    [Display(Name = "Логин")]
    [Required(ErrorMessage = "Введите логин")]
    public string Username { get; set; } = string.Empty;

    [Display(Name = "Пароль")]
    [Required(ErrorMessage = "Введите пароль")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = string.Empty;

    public string? ReturnUrl { get; set; }
}
