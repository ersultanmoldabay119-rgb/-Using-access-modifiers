using Microsoft.AspNetCore.Mvc.Rendering;

namespace CollegeManagement.Models.ViewModels;

/// <summary>Строка со сводной статистикой студента: средний балл и посещаемость.</summary>
public record StudentStat(
    int Id,
    string FullName,
    string Initials,
    int GroupId,
    string GroupName,
    double? Average,
    int GradesCount,
    double? AttendanceRate);

public class StudentListViewModel
{
    public string? Search { get; set; }
    public int? GroupId { get; set; }
    public List<StudentStat> Students { get; set; } = new();
    public List<SelectListItem> Groups { get; set; } = new();
}

public record SubjectProgress(int SubjectId, string SubjectName, string? TeacherName, double Average, List<Grade> Grades);

public class StudentProfileViewModel
{
    public Student Student { get; set; } = null!;
    public double? Average { get; set; }
    public int? RankInGroup { get; set; }
    public int GroupSize { get; set; }
    public AttendanceSummary Attendance { get; set; } = new();
    public List<Attendance> RecentAttendance { get; set; } = new();
    public List<SubjectProgress> Subjects { get; set; } = new();
}

public class StudentFormViewModel
{
    public Student Student { get; set; } = new();
    public List<SelectListItem> Groups { get; set; } = new();
}
