using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models;

public class Subject
{
    public int Id { get; set; }

    [Display(Name = "Название")]
    [Required(ErrorMessage = "Укажите название предмета")]
    [StringLength(100)]
    public string Name { get; set; } = string.Empty;

    [Display(Name = "Часов")]
    [Range(1, 1000, ErrorMessage = "От 1 до 1000 часов")]
    public int Hours { get; set; } = 72;

    [Display(Name = "Преподаватель")]
    public int? TeacherId { get; set; }
    public Teacher? Teacher { get; set; }

    public List<Grade> Grades { get; set; } = new();
}
