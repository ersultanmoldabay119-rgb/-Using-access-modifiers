using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models;

public class Teacher : Person
{
    [Display(Name = "Должность")]
    [Required(ErrorMessage = "Укажите должность")]
    [StringLength(80)]
    public string Position { get; set; } = "Преподаватель";

    [Display(Name = "Дата приёма")]
    [DataType(DataType.Date)]
    public DateTime HireDate { get; set; } = DateTime.Today;

    public List<Subject> Subjects { get; set; } = new();
    public List<Group> CuratedGroups { get; set; } = new();
}
