using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models;

/// <summary>
/// Базовый класс для студентов и преподавателей.
/// В БД отдельной таблицы нет — поля наследуются в таблицы Students и Teachers.
/// </summary>
public abstract class Person
{
    public int Id { get; set; }

    [Display(Name = "Фамилия")]
    [Required(ErrorMessage = "Укажите фамилию")]
    [StringLength(50)]
    public string LastName { get; set; } = string.Empty;

    [Display(Name = "Имя")]
    [Required(ErrorMessage = "Укажите имя")]
    [StringLength(50)]
    public string FirstName { get; set; } = string.Empty;

    [Display(Name = "Отчество")]
    [StringLength(50)]
    public string? MiddleName { get; set; }

    [Display(Name = "Email")]
    [EmailAddress(ErrorMessage = "Некорректный email")]
    [StringLength(100)]
    public string? Email { get; set; }

    [Display(Name = "Телефон")]
    [Phone(ErrorMessage = "Некорректный номер")]
    [StringLength(20)]
    public string? Phone { get; set; }

    [Display(Name = "Дата рождения")]
    [DataType(DataType.Date)]
    public DateTime? BirthDate { get; set; }

    public string FullName =>
        string.Join(' ', new[] { LastName, FirstName, MiddleName }.Where(s => !string.IsNullOrWhiteSpace(s)));

    public string ShortName =>
        $"{LastName} {Initial(FirstName)}{Initial(MiddleName)}".Trim();

    public string Initials => $"{Initial(FirstName, false)}{Initial(LastName, false)}";

    private static string Initial(string? s, bool dot = true) =>
        string.IsNullOrWhiteSpace(s) ? string.Empty : char.ToUpper(s[0]) + (dot ? "." : string.Empty);
}
