using System.ComponentModel.DataAnnotations;

namespace CollegeManagement.Models;

public static class Roles
{
    public const string Admin = "Admin";
    public const string Teacher = "Teacher";
}

public class User
{
    public int Id { get; set; }

    [Required, StringLength(50)]
    public string Username { get; set; } = string.Empty;

    [Required]
    public string PasswordHash { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string DisplayName { get; set; } = string.Empty;

    [Required, StringLength(20)]
    public string Role { get; set; } = Roles.Teacher;

    /// <summary>Связь с преподавателем, если пользователь — преподаватель.</summary>
    public int? TeacherId { get; set; }
    public Teacher? Teacher { get; set; }
}
